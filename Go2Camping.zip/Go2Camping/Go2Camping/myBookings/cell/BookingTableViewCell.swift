//
//  BookingTableViewCell.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 5/6/21.
//

import UIKit

class BookingTableViewCell: UITableViewCell {

    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var checkIn: UILabel!
    @IBOutlet weak var checkOut: UILabel!
    @IBOutlet weak var price: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func loadCell(booking: BookingDTO) {
        backgroundColor = .clear
        layer.masksToBounds = false
        layer.shadowOpacity = 0.23
        layer.shadowRadius = 4
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowColor = UIColor.black.cgColor
        contentView.backgroundColor = .white
        contentView.layer.cornerRadius = 8
        
        self.title.text = booking.camping
        self.title.styleTitleCampingCell()
        self.checkIn.text = "Entrada: \(booking.checkIn)"
        self.checkIn.styleBoookings()
        self.checkOut.text = "Salida: \(booking.checkOut)"
        self.checkOut.styleBoookings()
        self.price.text = "Precio: \(booking.price)"
        self.price.styleBoookings()
    }
    
}
