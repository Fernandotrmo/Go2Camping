//
//  MyBookingsViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 5/6/21.
//

import UIKit

class MyBookingsViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    var bookings: [BookingDTO] = []
    
    var ws: WebService!
    
    var email: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ws = WebService(delegateBookings: self)
        loadStyles()
    }
    
    func loadStyles() {
        self.table.backgroundColor = UIColor(red: 213/255, green: 245/255, blue: 227/255, alpha: 1)
        self.table.dataSource = self
        self.table.delegate = self
        self.table.register(UINib(nibName: "BookingTableViewCell", bundle: nil), forCellReuseIdentifier: "booking")
        ws.getBookings(email: email)
    }

}

extension MyBookingsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bookings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "booking") as? BookingTableViewCell else { return UITableViewCell() }
        cell.loadCell(booking: bookings[indexPath.row])
        cell.selectionStyle = .none
        return cell
    }
    
}

extension MyBookingsViewController: BookingsLoader {
    func bookingLoaded(bookings: [BookingDTO]) {
        self.bookings = bookings
        self.table.reloadData()
    }
    
    func error(error: Error) {
        print("Error \(error)")
    }
    
    
}
