//
//  CommentTableViewCell.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 31/5/21.
//

import HCSStarRatingView
import UIKit

class CommentTableViewCell: UITableViewCell {

    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var rating: HCSStarRatingView!
    @IBOutlet weak var lbComment: UILabel!
    @IBOutlet weak var lbDate: UILabel!
    
    var email: String = ""
    
    override func prepareForReuse() {
        super.prepareForReuse()
        self.rating.emptyStarImage = nil
        self.rating.filledStarImage = nil
    }
    
    func loadCell(averangeRating: RatingDTO) {
        self.lbName.text = averangeRating.nameUser
        self.lbName.styleNameCommentCamping()
        self.lbDate.text = averangeRating.date
        self.lbDate.styleDateComment()
        self.lbComment.text = averangeRating.comment
        self.lbComment.styleDescriptionCommentCamping()
        rating.backgroundColor = .clear
        rating.value = CGFloat(averangeRating.rating)
        rating.isUserInteractionEnabled = false
        rating.tintColor = UIColor(red: 255/255, green: 195/255, blue: 0, alpha: 1)
        
        backgroundColor = .clear
        layer.masksToBounds = false
        layer.shadowOpacity = 0.23
        layer.shadowRadius = 4
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowColor = UIColor.black.cgColor
        contentView.backgroundColor = .white
        contentView.layer.cornerRadius = 8
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
