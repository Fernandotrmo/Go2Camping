//
//  CommentsViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 31/5/21.
//

import UIKit

class CommentsViewController: UIViewController {

    @IBOutlet weak var table: UITableView!
    var btn = UIButton(type: .custom)
    
    var camping: CampingVO?
    
    var email: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadStyles()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        btn.removeFromSuperview()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        floatingButton()
        self.table.reloadData()
    }
    
    func loadStyles() {
        self.table.delegate = self
        self.table.dataSource = self
        self.table.backgroundColor = UIColor(red: 213/255, green: 245/255, blue: 227/255, alpha: 1)
        self.table.register(UINib(nibName: "CommentTableViewCell", bundle: nil), forCellReuseIdentifier: "comment")
        self.title = camping?.name ?? ""
    }
    
    func floatingButton(){
        btn.frame = CGRect(x: UIScreen.main.bounds.width / 1.5, y: UIScreen.main.bounds.height / 1.3, width: 100, height: 100)
        btn.setBackgroundImage(UIImage(named: "add_comment"), for: .normal)
        btn.backgroundColor = .clear
        btn.clipsToBounds = true
        btn.layer.cornerRadius = 50
        btn.layer.borderColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 50.0)
        btn.layer.borderWidth = 3.0
        btn.addTarget(self,action: #selector(goToAddComment), for: .touchUpInside)
        if let window = UIWindow.key {
            window.addSubview(btn)
        }
    }
    
    @objc func goToAddComment() {
        let vc = AddCommentViewController(nibName: "AddCommentViewController", bundle: nil)
        vc.camping = camping
        vc.delegate = self
        vc.email = self.email
        self.navigationController?.pushViewController(vc, animated: true)
    }

}

extension CommentsViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return camping?.rating.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "comment") as? CommentTableViewCell else { return UITableViewCell() }
        if let camping = camping {
            cell.loadCell(averangeRating: camping.rating[indexPath.row])
            cell.selectionStyle = .none
        }
        
        return cell
    }
    
    
}

extension UIWindow {
    static var key: UIWindow? {
        if #available(iOS 13, *) {
            return UIApplication.shared.windows.first { $0.isKeyWindow }
        } else {
            return UIApplication.shared.keyWindow
        }
    }
}

extension CommentsViewController: AddRating {
    func addRating(rating: RatingDTO) {
        guard let camping = camping else { return }
        camping.rating.append(rating)
        table.reloadData()
    }
}
