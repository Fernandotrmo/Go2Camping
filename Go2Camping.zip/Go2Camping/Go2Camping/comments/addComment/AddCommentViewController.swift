//
//  AddCommentViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 1/6/21.
//

import UIKit
import HCSStarRatingView

protocol AddRating {
    func addRating(rating: RatingDTO)
}

class AddCommentViewController: UIViewController {
    
    @IBOutlet weak var btnSend: UIButton!
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbDescription: UILabel!
    @IBOutlet weak var rating: HCSStarRatingView!
    @IBOutlet weak var textView: UITextView!
    
    var camping: CampingVO?
    var delegate: AddRating?
    private var ws: WebService!
    
    private var lastId: Int = -1
    
    var email: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadStyles()
        ws = WebService(delegateCampings: nil, delegatePushComment: self)
    }
    
    func loadStyles() {
        guard let camping = camping else { return }
        
        print("lastID \(lastId)")
        
        self.view.backgroundColor = UIColor(red: 234/255, green: 250/255, blue: 241/255, alpha: 1)
        self.lbTitle.text = "Opinión \(camping.name)"
        self.lbTitle.styleTitleCamping()
        self.lbDescription.text = "Tu opinión es de gran ayuda para que los demás usuarios tengan una experiencia óptima en sus vacaciones."
        self.textView.backgroundColor = UIColor(red: 248/255, green: 249/255, blue: 249/255, alpha: 1)
        self.textView.shadowTextView()
        rating.backgroundColor = .clear
        rating.value = 0
        rating.isUserInteractionEnabled = true
        rating.tintColor = UIColor(red: 255/255, green: 195/255, blue: 0, alpha: 1)
        
        self.btnSend.setTitle("Enviar valoración", for: .normal)
        self.btnSend.buttonBooking()
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func getNewId() -> Int {
        guard let camping = camping else { return 0 }
        return (camping.rating.last?.id ?? -1) + 1
    }

    @IBAction func actionSend(_ sender: Any) {
        guard let camping = camping else { return }
        let ratingSend = RatingDTO(id: getNewId(), rating: Int(rating.value), nameUser: email, date: dateFormat(date: Date(), format: "dd-MM-yyyy"), comment: textView.text)

        ws.saveComment(camping: camping, rating: ratingSend)
    }
    
    func dateFormat(date: Date, format f: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.dateFormat = f
        return dateFormatter.string(from: date)
    }
}

extension AddCommentViewController: InsertComment {
    func putComment(comment: RatingDTO) {
        delegate?.addRating(rating: comment)
        self.navigationController?.popViewController(animated: true)
    }
    
    func error(error: Error) {
        print("Error... \(error.localizedDescription)")
    }
}
