//
//  CampingVO.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 10/5/21.
//

import Foundation

class CampingVO {
    let image: String
    let name: String
    var rating: [RatingDTO]
    let price: Float
    let locality: String
    let images: [String]
    let description: String
    let latitude: String
    let longitude: String
    let town: String
    let id: Int
    
    init(campingDTO: CampingDTO) {
        self.image = campingDTO.images.first ?? ""
        self.name = campingDTO.name
        self.id = campingDTO.id
        self.rating = campingDTO.ratings
        self.price = campingDTO.price
        self.locality = campingDTO.location
        self.images = campingDTO.images
        self.description = campingDTO.description
        self.latitude = campingDTO.latitud
        self.longitude = campingDTO.longitud
        self.town = campingDTO.town
    }
    
    func calculateAvrange() -> Float {
        var averange: Float = 0
        for rate in rating {
            averange += Float(rate.rating)
        }
        
        averange = averange / Float(rating.count)
        
        return averange
    }
}
