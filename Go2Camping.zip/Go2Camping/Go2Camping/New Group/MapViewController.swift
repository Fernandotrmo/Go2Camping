//
//  MapViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 31/5/21.
//

import UIKit
import MapKit

class MapViewController: UIViewController {

    @IBOutlet weak var mapKit: MKMapView!
    
    var camping: CampingVO?
    
    let locationManager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadStyles()

        getUserLocation()
    }
    
    func loadStyles() {
        self.mapKit.delegate = self
    }
    
    func getUserLocation() {
        self.locationManager.requestAlwaysAuthorization()

        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        guard let camping = camping else { return }
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            let london = MKPointAnnotation()
            london.title = camping.name
            london.coordinate = CLLocationCoordinate2D(latitude: Double(camping.longitude) ?? 0, longitude: Double(camping.latitude) ?? 0)
            mapKit.addAnnotation(london)
        }
    }
    
    func addAnnotations(coords: [CLLocation]){
        for coord in coords{
            let CLLCoordType = CLLocationCoordinate2D(latitude: coord.coordinate.latitude,
                                                      longitude: coord.coordinate.longitude);
            let anno = MKPointAnnotation();
            anno.coordinate = CLLCoordType;
            mapKit.addAnnotation(anno);
        }
        
    }
}

extension MapViewController: CLLocationManagerDelegate {

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let camping = camping else { return }
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }

        let loc2 = CLLocationCoordinate2D.init(latitude: Double(camping.longitude) ?? 0 , longitude: Double(camping.latitude) ?? 0)
        let loc1 = CLLocationCoordinate2D.init(latitude: locValue.latitude , longitude: locValue.longitude)
        showRouteOnMap(pickupCoordinate: loc1, destinationCoordinate: loc2)
    }
}

extension MapViewController: MKMapViewDelegate {
    func showRouteOnMap(pickupCoordinate: CLLocationCoordinate2D, destinationCoordinate: CLLocationCoordinate2D) {

            let request = MKDirections.Request()
            request.source = MKMapItem(placemark: MKPlacemark(coordinate: pickupCoordinate, addressDictionary: nil))
            request.destination = MKMapItem(placemark: MKPlacemark(coordinate: destinationCoordinate, addressDictionary: nil))
            request.requestsAlternateRoutes = true
            request.transportType = .automobile

            let directions = MKDirections(request: request)

            directions.calculate { [unowned self] response, error in
                guard let unwrappedResponse = response else { return }
                
                //for getting just one route
                if let route = unwrappedResponse.routes.first {
                    //show on map
                    self.mapKit.addOverlay(route.polyline)
                    //set the map area to show the route
                    self.mapKit.setVisibleMapRect(route.polyline.boundingMapRect, edgePadding: UIEdgeInsets.init(top: 80.0, left: 20.0, bottom: 100.0, right: 20.0), animated: true)
                }
            }
        }
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
         let renderer = MKPolylineRenderer(overlay: overlay)
         renderer.strokeColor = UIColor(red: 118/255, green: 215/255, blue: 196/255, alpha: 1)
         renderer.lineWidth = 5.0
         return renderer
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        guard annotation is MKPointAnnotation else { return nil }

        let identifier = "Annotation"
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)

        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
            annotationView!.canShowCallout = true
        } else {
            annotationView!.annotation = annotation
        }

        return annotationView
    }
}
