//
//  CampingDetailViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 31/5/21.
//

import UIKit
import FSPagerView
import Kingfisher
import HCSStarRatingView
import MessageUI

class CampingDetailViewController: UIViewController, FSPagerViewDelegate,
                                   FSPagerViewDataSource {
    
    @IBOutlet weak var btBooking: UIButton!
    @IBOutlet weak var lbBooking: UILabel!
    @IBOutlet weak var rating: HCSStarRatingView!
    @IBOutlet weak var tfCheckOut: UITextField!
    @IBOutlet weak var btnLocality: UIButton!
    @IBOutlet weak var btnComment: UIButton!
    @IBOutlet weak var lbValoration: UILabel!
    @IBOutlet weak var tfCheckIn: UITextField!
    @IBOutlet weak var lbDescription: UILabel!
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var pager: FSPagerView! {
        didSet {
            self.pager.register(FSPagerViewCell.self, forCellWithReuseIdentifier: "cell")
        }
    }

    let datePicker = UIDatePicker()
    let toolBar = UIToolbar()
    
    var minDate: Date = Date()
    
    var camping: CampingVO?
    
    var booking: BookingDTO?
    
    var user: UserDTO?
    
    var emailUser: String = ""
    
    var price: Float = 0
    
    var checkInDate: Date = Date()
    var checkOutDate: Date = Date()
    
    private var ws: WebService!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ws = WebService()
        loadStyles()
        loadData()
    }
    
    func loadStyles() {
        guard let camping = camping else { return }
        self.view.backgroundColor = UIColor(red: 213/255, green: 245/255, blue: 227/255, alpha: 1)
        self.lbDescription.styleDescriptionCamping()
        self.lbTitle.styleTitleDetail()
        self.lbBooking.styleTitleCampingCell()
        self.lbValoration.styleTitleCampingCell()
        rating.backgroundColor = .clear
        rating.value = CGFloat(camping.calculateAvrange())
        rating.isUserInteractionEnabled = false
        rating.tintColor = UIColor(red: 255/255, green: 195/255, blue: 0, alpha: 1)
        
        self.tfCheckIn.addInputViewDatePicker(type: .Date, target: self, selector: #selector(doneButtonCheckIn), minDate: nil)
        self.tfCheckOut.isUserInteractionEnabled = false
        self.btBooking.buttonBooking()
        self.btnComment.buttonComment()
        self.btnLocality.buttonLocality()
        
    }

    @objc func doneButtonCheckIn() {
        self.tfCheckOut.text = nil
        if let  datePicker = tfCheckIn.inputView as? UIDatePicker {
            checkInDate = datePicker.date
            dateFormat(textField: tfCheckIn, datePicker: datePicker, format: "dd-MM-yyyy")
            minDate = datePicker.date
            let modifiedDate = Calendar.current.date(byAdding: .day, value: 1, to: minDate)!
            self.tfCheckOut.isUserInteractionEnabled = true
            self.tfCheckOut.addInputViewDatePicker(type: .Date, target: self, selector: #selector(doneButtonCheckOut), minDate: modifiedDate)
            self.btBooking.setTitle("Reservar", for: .normal)
        }
    }
    
    @objc func doneButtonCheckOut() {
        if let  datePicker = tfCheckOut.inputView as? UIDatePicker {
            checkOutDate = datePicker.date
            dateFormat(textField: tfCheckOut, datePicker: datePicker, format: "dd-MM-yyyy")
            
            if let checkIn = tfCheckIn.text, let camping = camping, let checkOut = tfCheckOut.text, !checkIn.isEmpty, !checkOut.isEmpty {
                let days = self.daysBetweenDates(startDate: checkInDate, endDate: checkOutDate)
                let price = Float(days) * camping.price
                self.btBooking.setTitle("Reservar por \(price)€", for: .normal)
                
            }
        }
    }

    @IBAction func actionBooking(_ sender: Any) {
        guard let camping = camping else  { return }
        if let checkIn = tfCheckIn.text, let checkOut = tfCheckOut.text, !checkIn.isEmpty, !checkOut.isEmpty {
            let days = self.daysBetweenDates(startDate: checkInDate, endDate: checkOutDate)
            let price = Float(days) * camping.price
            self.price = price
            let booking = BookingDTO(user: self.emailUser, checkIn: tfCheckIn.text ?? "", checkOut: tfCheckOut.text ?? "", price: price, camping: camping.name)
            self.booking = booking
            
            let alert = UIAlertController(title: "Atención", message: "¿Seguro/a que desea reservar \(days) días por \(price)€?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: { [ weak self ] UIAlertAction in
                guard let self = self else { return }
                self.showEmailComposer()
            }))
            alert.addAction(UIAlertAction(title: "Cancelar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        } else {
            let alert = UIAlertController(title: "Atención", message: "Hay que registrar fecha de entrada y de salida para poder reservar", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    @IBAction func goToComment(_ sender: Any) {
        let vc = CommentsViewController(nibName: "CommentsViewController", bundle: nil)
        vc.camping = camping
        vc.email = self.emailUser
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showEmailComposer() {
        guard MFMailComposeViewController.canSendMail() else {
            return
        }
        
        let composer = MFMailComposeViewController()
        composer.mailComposeDelegate = self
        composer.setToRecipients([emailUser])
        composer.setSubject("Reserva \(camping!.name)")
        composer.setMessageBody("Gracias por reservar con nosotros \n \n Información de la reserva: \n \n Reserva realizada en \(camping!.name). \n Fecha de entrada: \(checkInDate) \n Fecha de salida: \(checkOutDate) \n Precio: \(price)€ \n Usuario: \(user?.name ?? "") \n DNI: \(user?.dni ?? "") \n Fecha de nacimiento: \(user?.date ?? "")", isHTML: false)
        
        present(composer, animated: true)
    }
    
    //Estilo de la fecha y hora
    func dateFormat(textField tf: UITextField, datePicker dp: UIDatePicker, format f: String){
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.dateFormat = f
        tf.text = dateFormatter.string(from: dp.date)
        tf.resignFirstResponder()
    }
    @IBAction func actionLocality(_ sender: Any) {
        let vc = MapViewController(nibName: "MapViewController", bundle: nil)
        vc.camping = camping
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func loadData() {
        guard let camping = camping else { return }
        self.lbTitle.text = camping.name
        self.pager.delegate = self
        self.lbValoration.text = "Valoración"
        self.pager.dataSource = self
        self.tfCheckIn.placeholder = "Fecha de entrada"
        self.tfCheckOut.placeholder = "Fecha de salida"
        self.lbBooking.text = "Reservar"
        self.lbDescription.text = camping.description
        self.btBooking.setTitle("Reservar", for: .normal)
        self.btnComment.setTitle("Comentarios", for: .normal)
        self.btnLocality.setTitle("Localizar", for: .normal)

    }
    
    public func numberOfItems(in pagerView: FSPagerView) -> Int {
     return camping?.images.count ?? 0
    }

    public func pagerView(_ pagerView: FSPagerView, cellForItemAt index: Int) -> FSPagerViewCell {
     guard let camping = camping else { return FSPagerViewCell() }
     
     let url = URL(string: camping.images[index])
     let cell = pagerView.dequeueReusableCell(withReuseIdentifier: "cell", at: index)
     if let url = url {
         cell.imageView?.kf.setImage(with: url, placeholder: UIImage(named: "cargando"))
         cell.textLabel?.text = "..."
     } else {
         cell.imageView?.image = UIImage(named: "img_no_disponible")
         print("url camping \(camping.image)")
     }
        return cell
    }

    func daysBetweenDates(startDate: Date, endDate: Date) -> Int {
        let calendar = NSCalendar.current
        
        let components = calendar.dateComponents([.day], from: calendar.startOfDay(for: startDate), to: calendar.startOfDay(for: endDate))

        return (components.day ?? 0)
    }

}

extension CampingDetailViewController: MFMailComposeViewControllerDelegate {
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        if let _ = error {
            controller.dismiss(animated: true, completion: nil)
            let alert = UIAlertController(title: "Error", message: "UPS! se ha producido un error, vuelve a intentarlo más tarde.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        switch result {
            case .cancelled:
               print("cancelled")
            case .failed:
                controller.dismiss(animated: true, completion: nil)
                let alert = UIAlertController(title: "Error", message: "UPS! se ha producido un error, vuelve a intentarlo más tarde.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            case .saved:
                print("saved")
            case .sent:
                controller.dismiss(animated: true, completion: nil)
                let alert = UIAlertController(title: "Éxito", message: "Reserva realizada con éxito.", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                if let booking = self.booking {
                    self.ws.pushBooking(booking: booking)
                }
            @unknown default:
                break
        }
        
        controller.dismiss(animated: true, completion: nil)
    }
}
