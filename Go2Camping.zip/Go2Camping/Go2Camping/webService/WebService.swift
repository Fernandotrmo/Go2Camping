//
//  WebService.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 10/5/21.
//

import Foundation
import FirebaseDatabase
import FirebaseCore
import CodableFirebase
import FirebaseAuth


protocol CampingsLoaded {
    func campingsLoaded(campings: [CampingDTO])
    func error(error: Error)
}

protocol InsertComment {
    func putComment(comment: RatingDTO)
    func error(error: Error)
}

protocol CreateUser {
    func userCreated(result: AuthDataResult)
    func error(error: Error)
}

protocol BookingsLoader {
    func bookingLoaded(bookings: [BookingDTO])
    func error(error: Error)
}

protocol InsertPersonalData {
    func personalDataInsert()
    func error(error: Error)
}

protocol CheckUser {
    func foundUser(user: UserDTO)
    func notFoundUser(email: String)
    func error(error: Error)
}

class WebService {
    var dataBase: DatabaseReference!
    var delegateCampingsLoaded: CampingsLoaded?
    var delegateInsertComment: InsertComment?
    var delegateCreateUser: CreateUser?
    var delegateBookings: BookingsLoader?
    var delegatePersonalData: InsertPersonalData?
    var delegateCheckUser: CheckUser?
    
    
    init(delegateCheckUser: CheckUser? = nil, delegatePersonalData: InsertPersonalData? = nil, delegateBookings: BookingsLoader? = nil, delegateCreateUser: CreateUser? = nil, delegateCampings: CampingsLoaded? = nil, delegatePushComment: InsertComment? = nil) {
        dataBase = Database.database().reference()
        self.delegateInsertComment = delegatePushComment
        self.delegateCampingsLoaded = delegateCampings
        self.delegateCreateUser = delegateCreateUser
        self.delegateBookings = delegateBookings
        self.delegatePersonalData = delegatePersonalData
        self.delegateCheckUser = delegateCheckUser
    }
    
    func getCampings() {
        var _: [CampingDTO]?
        dataBase.child("campings").observeSingleEvent(of: .value, with: {[weak self] (snapshot)  in
            guard let self = self else { return }
            guard let value = snapshot.value else { return }
            do {
                let campings = try FirebaseDecoder().decode([CampingDTO].self, from: value)
                self.delegateCampingsLoaded?.campingsLoaded(campings: campings)
            } catch let error {
                self.delegateCampingsLoaded?.error(error: error)
            }
        })
    }
    
    func getUser(email: String) {
        dataBase.child("users").observeSingleEvent(of: .value, with: {[weak self] (snapshot)  in
            guard let self = self else { return }
            guard let value = snapshot.value else { return }
            print("Valor \(value) ")
            do {
                let users = try FirebaseDecoder().decode([String: UserDTO].self, from: value)
                let myUsers = users.filter { $0.value.email == email }
                if myUsers.isEmpty {
                    self.delegateCheckUser?.notFoundUser(email: email)
                } else if let u = myUsers.first {
                    self.delegateCheckUser?.foundUser(user: u.value)
                }

            } catch let error {
                self.delegateCheckUser?.error(error: error)
            }
        })
    }
    
    func getBookings(email: String) {
        var _: [BookingDTO]?
        dataBase.child("bookings").observeSingleEvent(of: .value, with: {[weak self] (snapshot)  in
            guard let self = self else { return }
            guard let value = snapshot.value else { return }
            print("Valor \(value) ")
            do {
                let bookings = try FirebaseDecoder().decode([String: BookingDTO].self, from: value)
                let myBooking = bookings.filter { $0.value.user == email }
                var bookingsSend: [BookingDTO] = []
                for b in myBooking {
                    bookingsSend.append(b.value)
                }
                self.delegateBookings?.bookingLoaded(bookings: bookingsSend)

            } catch let error {
                self.delegateBookings?.error(error: error)
            }
        })
    }
    
    func saveComment(camping: CampingVO, rating: RatingDTO) {
        let ref = dataBase.child("campings/\(camping.id)")
        let post = ["id": rating.id,
                    "comment": rating.comment,
                    "date": rating.date,
                    "nameUser": rating.nameUser,
                    "rating": rating.rating] as [String : Any]
        
        let childUpdates = ["/ratings/\(rating.id)": post]
        ref.updateChildValues(childUpdates)

        ref.updateChildValues(childUpdates) { error, ref in
            if let error = error {
                self.delegateInsertComment?.error(error: error)
            } else {
                self.delegateInsertComment?.putComment(comment: rating)
            }
        }
    }
    
    func pushBooking(booking: BookingDTO) {
        let post = ["user": booking.user,
                    "checkIn": booking.checkIn,
                    "checkOut": booking.checkOut,
                    "price": booking.price,
                    "camping": booking.camping] as [String : Any]
        
        self.dataBase.child("bookings").childByAutoId().updateChildValues(post) { error, reference in
            if let error = error {
                print("Error \(error.localizedDescription)")
            } else {
                print("subido")
            }
        }
    }
    
    func pushUser(user: UserDTO) {
        let post = ["email": user.email,
                    "name": user.name,
                    "dni": user.dni,
                    "province": user.province,
                    "date": user.date] as [String : Any]
        self.dataBase.child("users").childByAutoId().updateChildValues(post) { [weak self] error, reference in
            guard let self = self else { return }
            if let error = error {
                self.delegatePersonalData?.error(error: error)
            } else {
                self.delegatePersonalData?.personalDataInsert()
            }
        }
    }
    
    func createUser(email: String, password: String) {
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let result = result, error == nil {
                self.delegateCreateUser?.userCreated(result: result)
            } else {
                if let error = error {
                    self.delegateCreateUser?.error(error: error)
                }
            }
        }
    }
    
    func login(email: String, password: String) {
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let result = result, error == nil {
                self.delegateCreateUser?.userCreated(result: result)
            } else {
                if let error = error {
                    self.delegateCreateUser?.error(error: error)
                }
            }
        }
    }
}
