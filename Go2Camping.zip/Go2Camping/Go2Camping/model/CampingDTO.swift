//
//  camping.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 10/5/21.
//

import Foundation

struct CampingDTO: Codable {
    let id: Int
    let description: String
    let images: [String]
    let latitud: String
    let longitud: String
    let location: String
    let name: String
    let price: Float
    let town: String
    let ratings: [RatingDTO]
}
