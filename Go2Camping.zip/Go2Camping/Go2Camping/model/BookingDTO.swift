//
//  BookingDTO.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 5/6/21.
//

import Foundation

struct BookingDTO: Codable {
    let user: String
    let checkIn: String
    let checkOut: String
    let price: Float
    let camping: String
}

struct ResultDTO: Codable {
    let bookings: [String: BookingDTO]
}
