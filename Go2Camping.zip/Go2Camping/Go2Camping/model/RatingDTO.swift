//
//  RatingDTO.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 10/5/21.
//

import Foundation

struct RatingDTO: Codable {
    let id: Int
    let rating: Int
    let nameUser: String
    let date: String
    let comment: String
}
