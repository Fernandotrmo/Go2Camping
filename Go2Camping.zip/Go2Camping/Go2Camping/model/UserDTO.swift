//
//  UserDTO.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 8/6/21.
//

import Foundation

struct UserDTO: Codable {
    let name: String
    let email: String
    let date: String
    let dni: String
    let province: String
}
