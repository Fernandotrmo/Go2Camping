//
//  CampingTableViewCell.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 10/5/21.
//

import UIKit
import Kingfisher
import HCSStarRatingView

class CampingTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgCamping: UIImageView!
    @IBOutlet weak var rating: HCSStarRatingView!
    @IBOutlet weak var lbLocality: UILabel!
    @IBOutlet weak var lbPrice: UILabel!
    @IBOutlet weak var stack: UIStackView!
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var viewRating: UIView!
    @IBOutlet weak var viewName: UIView!
    
    static let identifier = "campingCellIdentifier"

    override func prepareForReuse() {
        super.prepareForReuse()
        self.imgCamping.image = nil
        self.lbPrice.text = nil
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10))
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func loadCell(camping: CampingVO) {
        let url = URL(string: camping.image)
        if let url = url {
            imgCamping.kf.setImage(with: url, placeholder: UIImage(named: "cargando"))
        } else {
            imgCamping.image = UIImage(named: "img_no_disponible")
            print("url camping \(camping.image)")
        }
        
        self.viewName.backgroundColor = .clear
        self.stack.backgroundColor = .clear
        self.viewRating.backgroundColor = .clear
        rating.backgroundColor = .clear
        rating.value = CGFloat(camping.calculateAvrange())
        rating.isUserInteractionEnabled = false
        rating.tintColor = UIColor(red: 255/255, green: 195/255, blue: 0, alpha: 1)
        self.lbPrice.text = "\(camping.price) €"
        self.lbPrice.styleLocaliteCampingCell()
        self.lbName.text = camping.name
        self.lbName.styleTitleCampingCell()
        self.lbLocality.text = "\(camping.town), \(camping.locality)"
        self.lbLocality.styleLocaliteCampingCell()
        
        backgroundColor = .clear
        layer.masksToBounds = false
        layer.shadowOpacity = 0.23
        layer.shadowRadius = 4
        layer.shadowOffset = CGSize(width: 0, height: 0)
        layer.shadowColor = UIColor.black.cgColor
        contentView.backgroundColor = .white
        contentView.layer.cornerRadius = 8
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
}
