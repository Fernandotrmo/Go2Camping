//
//  CampingListViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 10/5/21.
//

import UIKit

enum ProvicerType {
    case basic
    case google
}

class CampingListViewController: UIViewController {

    @IBOutlet weak var viewTable: UIView!
    @IBOutlet weak var table: UITableView!
    
    private var ws: WebService!
    private var campings: [CampingDTO] = []
    private var originalCampings: [CampingVO] = []
    private var campingsVO: [CampingVO] = []
    
    private var provinces: [String] = ["Todas las provincias"]
    private var provinceSelected: String = ""
    
    var email: String = ""
    var provider: ProvicerType = .basic
    
    var user: UserDTO? = nil
    
    var toolBar = UIToolbar()
    var picker  = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ws = WebService(delegateCheckUser: self, delegateCampings: self)
        loadStyles()
        loadData()
        print("Usuario logado \(email)")
        ws.getUser(email: email)
    }
    
    private func loadStyles() {
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Filtrar", style: .done, target: self, action: #selector(filter))
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Perfil", style: .done, target: self, action: #selector(profile))
        
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        self.title = "Campings"
        
        self.table.delegate = self
        self.table.dataSource = self
        self.table.separatorStyle = .none
        
        self.table.backgroundColor = UIColor(red: 213/255, green: 245/255, blue: 227/255, alpha: 1)
        self.table.register(UINib(nibName: "CampingTableViewCell", bundle: nil), forCellReuseIdentifier: CampingTableViewCell.identifier)
        
        picker = UIPickerView.init()
        picker.delegate = self
        picker.dataSource = self
        picker.backgroundColor = UIColor.white
        picker.setValue(UIColor.black, forKey: "textColor")
        picker.autoresizingMask = .flexibleWidth
        picker.contentMode = .center
        picker.frame = CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 300)
        
        toolBar = UIToolbar.init(frame: CGRect.init(x: 0.0, y: UIScreen.main.bounds.size.height - 300, width: UIScreen.main.bounds.size.width, height: 50))
        toolBar.barStyle = .default
        toolBar.items = [UIBarButtonItem.init(title: "Filtrar", style: .done, target: self, action: #selector(actionFilter))]
    }
    
    private func saveUser() {
        let defaults = UserDefaults.standard
        defaults.setValue(email, forKey: "email")
        defaults.synchronize()
    }
    
    private func loadData() {
        ws.getCampings()
    }
    
    @objc func filter() {
        self.view.addSubview(picker)
        self.view.addSubview(toolBar)
    }
    
    @objc func profile() {
        let vc = PerosnalDataGetViewController(nibName: "PerosnalDataGetViewController", bundle: nil)
        if let user = user {
            vc.user = user
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @objc func actionFilter() {
        toolBar.removeFromSuperview()
        picker.removeFromSuperview()
        filterProvinces(province: provinceSelected)
    }
    
    private func getProvinces() {
        for camping in campings {
            let province = provinces.filter { $0 == camping.location }
            if province.isEmpty {
                provinces.append(camping.location)
                print("Añado \(camping.location)")
            }
        }
    }
    
    private func filterProvinces(province: String) {
        if province == "Todas las provincias" {
            self.campingsVO = originalCampings
        } else {
            self.campingsVO = originalCampings.filter { $0.locality == province }
        }
        
        self.table.reloadData()
    }
}

extension CampingListViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
        
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return provinces.count
    }
        
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return provinces[row]
    }
        
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        provinceSelected = provinces[row]
    }
}

extension CampingListViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return campingsVO.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: CampingTableViewCell.identifier) as? CampingTableViewCell else { return UITableViewCell() }
        cell.loadCell(camping: campingsVO[indexPath.row])
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.contentView.layer.masksToBounds = true
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let user = user {
            let vc = CampingDetailViewController(nibName: "CampingDetailViewController", bundle: nil)
            vc.camping =  campingsVO[indexPath.row]
            vc.emailUser = self.email
            vc.user = user
            if let navigation = navigationController {
                navigation.pushViewController(vc, animated: true)
            } else {
                print("Noo")
            }
        }
    }
}

extension CampingListViewController: CampingsLoaded {
    func campingsLoaded(campings: [CampingDTO]) {
        self.campings = campings
        campingsVO = campings.map { CampingVO(campingDTO: $0) }
        self.originalCampings = campingsVO
        getProvinces()
        self.table.reloadData()
    }
    
    func error(error: Error) {
        print("Error... \(error)")
    }
}

extension CampingListViewController: CheckUser {
    func foundUser(user: UserDTO) {
        print("usuario encontrado")
        self.user = user
    }
    
    func notFoundUser(email: String) {
        print("Usuario no encontrado")
        let vc = PersonalDataSetViewController(nibName: "PersonalDataSetViewController", bundle: nil)
        vc.email = email
        if let navigation = navigationController {
            navigation.pushViewController(vc, animated: true)
        }
    }
}
