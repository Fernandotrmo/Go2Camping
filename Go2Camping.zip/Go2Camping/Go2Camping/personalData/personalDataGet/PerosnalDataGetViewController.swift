//
//  PerosnalDataGetViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 8/6/21.
//

import UIKit

class PerosnalDataGetViewController: UIViewController {

    @IBOutlet weak var lbEmail: UILabel!
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbDate: UILabel!
    @IBOutlet weak var lbProvince: UILabel!
    @IBOutlet weak var lbDni: UILabel!
    @IBOutlet weak var btnBookings: UIButton!
    
    var user: UserDTO?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadStyles()

    }
    
    func loadStyles() {
        //Status bar
        let statusBarView = UIView()
        view.addSubview(statusBarView)
        statusBarView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            statusBarView.topAnchor.constraint(equalTo: view.topAnchor),
            statusBarView.leftAnchor.constraint(equalTo: view.leftAnchor),
            statusBarView.rightAnchor.constraint(equalTo: view.rightAnchor),
            statusBarView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
        ])
        statusBarView.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        navigationController?.navigationBar.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        self.view.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        guard let user = user else {  return }
        lbName.text = "   Nombre: \(user.name)"
        lbEmail.text = "   Email: \(user.email)"
        lbDni.text = "   DNI: \(user.dni)"
        lbDate.text = "   Fecha de nacimiento: \(user.date)"
        lbProvince.text = "   Provincia \(user.province)"
        
        lbName.stylePerosnalData()
        lbEmail.stylePerosnalData()
        lbDni.stylePerosnalData()
        lbDate.stylePerosnalData()
        lbProvince.stylePerosnalData()
        
        self.btnBookings.setTitle("Mis reservas", for: .normal)
        self.btnBookings.backgroundColor = UIColor(red: 86/255, green: 101/255, blue: 115/255, alpha: 1)
        self.btnBookings.setTitleColor(.white, for: .normal)
        self.btnBookings.titleLabel?.styleNameCommentCamping()
    }

    @IBAction func myBookings(_ sender: Any) {
        guard let user = user else {  return }
        let vc = MyBookingsViewController(nibName: "MyBookingsViewController", bundle: nil)
        vc.email = user.email
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
