//
//  PersonalDataSetViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 8/6/21.
//

import UIKit

class PersonalDataSetViewController: UIViewController {
    
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var tfDate: UITextField!
    @IBOutlet weak var tfDNI: UITextField!
    @IBOutlet weak var tfLocality: UITextField!
    @IBOutlet weak var btnAccept: UIButton!
    
    var email: String = ""
    
    private var ws: WebService!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ws = WebService(delegatePersonalData: self)
        loadStyles()
        // Do any additional setup after loading the view.
    }
    
    func loadStyles() {
        //Status bar
        let statusBarView = UIView()
        view.addSubview(statusBarView)
        statusBarView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            statusBarView.topAnchor.constraint(equalTo: view.topAnchor),
            statusBarView.leftAnchor.constraint(equalTo: view.leftAnchor),
            statusBarView.rightAnchor.constraint(equalTo: view.rightAnchor),
            statusBarView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
        ])
        statusBarView.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        navigationController?.navigationBar.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        self.navigationItem.setHidesBackButton(true, animated: false)
        
        self.view.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        self.btnAccept.setTitle("Guardar datos", for: .normal)
        self.btnAccept.backgroundColor = UIColor(red: 86/255, green: 101/255, blue: 115/255, alpha: 1)
        self.btnAccept.setTitleColor(.white, for: .normal)
        self.btnAccept.titleLabel?.styleNameCommentCamping()
        
        self.tfName.placeholder = "Nombre"
        
        self.tfDNI.placeholder = "DNI"
        
        self.tfDate.placeholder = "Fecha de nacimiento"
        self.tfDate.addInputViewDatePicke(type: .Date, target: self, selector: #selector(done), minDate: nil)
        
        self.tfLocality.placeholder = "Provincia"
        
        self.title = "Datos personales"
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc func done() {
        if let datePicker = tfDate.inputView as? UIDatePicker {
            dateFormat(textField: tfDate, datePicker: datePicker, format: "dd-MM-yyyy")
        }
    }
    
    @IBAction func actionAcept(_ sender: Any) {
        if let dni = tfDNI.text, let name = tfName.text, let date = tfDate.text, let province = tfLocality.text, !dni.isEmpty, !name.isEmpty, !date.isEmpty, !province.isEmpty {
            if !Util.validateSpanishNationalIdentifier(nationalID: dni) {
                let alert = UIAlertController(title: "Error", message: "Introduce un DNI válido", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            let user = UserDTO(name: name, email: email, date: date, dni: dni, province: province)
            ws.pushUser(user: user)
        } else {
            let alert = UIAlertController(title: "Error", message: "No puede haber campos en blanco", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func dateFormat(textField tf: UITextField, datePicker dp: UIDatePicker, format f: String){
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.dateFormat = f
        tf.text = dateFormatter.string(from: dp.date)
        tf.resignFirstResponder()
    }
}

extension PersonalDataSetViewController: InsertPersonalData {
    func personalDataInsert() {
        let vc = CampingListViewController(nibName: "CampingListViewController", bundle: nil)
        vc.email = self.email
        vc.provider = .basic
        if let navigation = navigationController {
            navigation.pushViewController(vc, animated: true)
        }
    }
    
    func error(error: Error) {
        print("Error: \(error.localizedDescription)")
    }
    
    
}
