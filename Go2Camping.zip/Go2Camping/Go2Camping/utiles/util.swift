//
//  util.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 8/6/21.
//

import Foundation

class Util {
    public static func validateSpanishNationalIdentifier(nationalID: String) -> Bool {
            if nationalID.count < 9 {
                return false
            }
            let buffer = NSMutableString(string: nationalID)
            let opts = NSString.CompareOptions()
            let rng = NSMakeRange(0, 1)
            buffer.replaceOccurrences(of: "X", with: "0", options: opts, range: rng)
            buffer.replaceOccurrences(of: "Y", with: "1", options: opts, range: rng)
            buffer.replaceOccurrences(of: "Z", with: "2", options: opts, range: rng)
            
            if let baseNumber = Int(buffer.substring(to: 8)) {
                let letterMap1 = "TRWAGMYFPDXBNJZSQVHLCKET"
                let letterMap2 = "TRWAGMYFPDXBNJZSQVHLCKET".lowercased()
                
                let letterIdx = baseNumber % 23
                
                //Find case sensitive letter
                var expectedLetter = letterMap1[letterMap1.index(letterMap1.startIndex, offsetBy: letterIdx)]
                var providedLetter = nationalID[nationalID.index(before: nationalID.endIndex)]
                
                if(expectedLetter == providedLetter){
                    return true
                }else{
                    expectedLetter = letterMap2[letterMap2.index(letterMap2.startIndex, offsetBy: letterIdx)]
                    providedLetter = nationalID[nationalID.index(before: nationalID.endIndex)]
                    
                    return expectedLetter == providedLetter
                }
                
            } else {
                return false
            }
            
        }
        
        public static func digitsSum(_ value:Int) -> Int {
            var currentResult: Int = 0
            var currentValue = value
            
            if(currentValue <= 100 && currentValue > 10)
            {
                currentResult += currentValue%10
                currentValue /= 10
                currentResult += currentValue
                return currentResult
            }
            
            if(currentValue == 10)
            {
                currentResult += 1
                return currentResult
            }
            
            return currentResult;
        }
}

extension String {
    func isValidEmail() -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"

        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: self)
    }
}
