//
//  UIButton + extension.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 7/6/21.
//

import Foundation
import UIKit
extension UIButton {
    func addIcon(icon: String, text: String, color:UIColor) {
        let iconWithPlaceholder = icon + " "
        let iconRange = (iconWithPlaceholder as NSString).range(of: icon)

        let attributedString = NSMutableAttributedString(string: iconWithPlaceholder + text)
        attributedString.addAttributes([NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 16.0) as Any], range: iconRange)

        self.setAttributedTitle(attributedString, for: .normal)
        self.tintColor = color
    }
}
