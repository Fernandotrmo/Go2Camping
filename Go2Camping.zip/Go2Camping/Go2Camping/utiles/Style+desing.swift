//
//  Style+desing.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 11/5/21.
//

import Foundation
import UIKit

extension UILabel {
    func styleTitleCampingCell() {
        self.font = UIFont(name: "PTSans-NarrowBold", size: 18)
    }
    
    func styleLocaliteCampingCell() {
        self.font = UIFont(name: "PTSans-Narrow", size: 16)
    }
    
    func styleBoookings() {
        self.font = UIFont(name: "PTSans-Narrow", size: 20)
    }
    
    func styleDescriptionCamping() {
        self.font = UIFont(name: "PTSans-Narrow", size: 13)
    }
    
    func styleTitleCamping() {
        self.font = UIFont(name: "PTSans-NarrowBold", size: 22)
    }
    
    func styleNameCommentCamping() {
        self.font = UIFont(name: "PTSans-NarrowBold", size: 18)
    }
    
    func styleDescriptionCommentCamping() {
        self.font = UIFont(name: "PTSans-Narrow", size: 15)
    }
    
    func styleDateComment() {
        self.font = UIFont(name: "PTSans-Narrow", size: 13)
        self.textColor = UIColor.darkGray
    }
    
    func styleTitleDetail() {
        self.font = UIFont(name: "DancingScript-SemiBold", size: 30)
    }
    
    func stylePerosnalData() {
        self.font = UIFont(name: "PTSans-NarrowBold", size: 22)
        self.backgroundColor = UIColor(red: 235/255, green: 245/255, blue: 251/255, alpha: 1)
        self.layer.cornerRadius = 15
        self.clipsToBounds = true
    }

}

extension UITextView {
    func shadowTextView() {
        self.layer.cornerRadius = 5
        self.clipsToBounds = false
        self.layer.shadowOpacity=0.1
        self.layer.shadowOffset = CGSize(width: 3, height: 3)
    }
}

extension UIButton {

    func buttonBooking() {
        self.layer.cornerRadius = 15
        self.backgroundColor = UIColor(red: 162/255, green: 217/255, blue: 206/255, alpha: 1)
        self.clipsToBounds = true
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16.0)
        self.tintColor = UIColor.white
    }

    func buttonLocality() {
        self.layer.cornerRadius = 15
        self.backgroundColor = UIColor(red: 169/255, green: 223/255, blue: 191/255, alpha: 1)
        self.clipsToBounds = true
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16.0)
        self.tintColor = UIColor.white
    }
    
    func buttonComment() {
        self.layer.cornerRadius = 15
        self.backgroundColor = UIColor(red: 118/255, green: 215/255, blue: 196/255, alpha: 1)
        self.clipsToBounds = true
        self.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16.0)
        self.tintColor = UIColor.white
    }
}
