//
//  UITextField + extensions.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 31/5/21.
//

import Foundation
import UIKit

enum TypeDatepicke {
    case Date
    case Time
}

extension UITextField {
    
    func datePicker<T>(target: T,
                       doneAction: Selector,
                       cancelAction: Selector,
                       datePickerMode: UIDatePicker.Mode = .date) {
    }
    
    //Añadir un datepicker
    
    func addInputViewDatePicke(type: TypeDatepicke, target: Any, selector: Selector, minDate: Date?) {
        let screenWidth = UIScreen.main.bounds.width
        //añadimos datepicker
        
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        
        if let minDate = minDate {
            datePicker.minimumDate = minDate
        }
        
        switch type {
        case .Date:
            datePicker.datePickerMode = .date
        case .Time:
            datePicker.datePickerMode = .time
        }
        self.inputView = datePicker
        
        //Ponemos el idioma en español
        let loc = Locale(identifier: "es")
        datePicker.locale = loc

        //Añadir una toolbar con los botones necesarios
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 44))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelBarButton = UIBarButtonItem(title: "Cancelar", style: .plain, target: self, action: #selector(cancelPressed))
        let doneBarButton = UIBarButtonItem(title: "Aceptar", style: .plain, target: target, action: selector)
        toolBar.setItems([cancelBarButton, flexibleSpace, doneBarButton], animated: false)

        self.inputAccessoryView = toolBar
     }
    
    func addInputViewDatePicker(type: TypeDatepicke, target: Any, selector: Selector, minDate: Date?) {
        let screenWidth = UIScreen.main.bounds.width
        //añadimos datepicker
        
        let datePicker = UIDatePicker(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 216))
        
        if let minDate = minDate {
            datePicker.minimumDate = minDate
        } else {
            datePicker.minimumDate = Date()
        }
        
        switch type {
        case .Date:
            datePicker.datePickerMode = .date
        case .Time:
            datePicker.datePickerMode = .time
        }
        self.inputView = datePicker
        
        //Ponemos el idioma en español
        let loc = Locale(identifier: "es")
        datePicker.locale = loc

        //Añadir una toolbar con los botones necesarios
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 44))
        let flexibleSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let cancelBarButton = UIBarButtonItem(title: "Cancelar", style: .plain, target: self, action: #selector(cancelPressed))
        let doneBarButton = UIBarButtonItem(title: "Aceptar", style: .plain, target: target, action: selector)
        toolBar.setItems([cancelBarButton, flexibleSpace, doneBarButton], animated: false)

        self.inputAccessoryView = toolBar
     }

    //Cuando cancelas no haces nada
    @objc func cancelPressed() {
        self.resignFirstResponder()
    }
    
}
