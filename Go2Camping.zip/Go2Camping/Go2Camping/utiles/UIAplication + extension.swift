//
//  UIAplication + extension.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 11/5/21.
//
import UIKit
import Foundation

extension UIApplication {
    class var statusBarBackgroundColor: UIColor? {
        get {
            return (shared.value(forKey: "statusBar") as? UIView)?.backgroundColor
        } set {
            (shared.value(forKey: "statusBar") as? UIView)?.backgroundColor = newValue
        }
    }
}
