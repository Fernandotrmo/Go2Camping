//
//  RegisterViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 7/6/21.
//

import UIKit
import FirebaseAuth
import GoogleSignIn

class RegisterViewController: UIViewController {

    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var tfRepeatPassword: UITextField!
    @IBOutlet weak var btnRegister: UIButton!
    var webService: WebService!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webService = WebService(delegateCreateUser: self)
        loadStyles()
    }
    
    func loadStyles() {
        //Status bar
        let statusBarView = UIView()
        view.addSubview(statusBarView)
        statusBarView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            statusBarView.topAnchor.constraint(equalTo: view.topAnchor),
            statusBarView.leftAnchor.constraint(equalTo: view.leftAnchor),
            statusBarView.rightAnchor.constraint(equalTo: view.rightAnchor),
            statusBarView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
        ])
        statusBarView.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        navigationController?.navigationBar.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        self.view.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        self.btnRegister.setTitle("Registrarse", for: .normal)
        self.btnRegister.backgroundColor = UIColor(red: 86/255, green: 101/255, blue: 115/255, alpha: 1)
        self.btnRegister.setTitleColor(.white, for: .normal)
        self.btnRegister.titleLabel?.styleNameCommentCamping()
        
        self.tfEmail.placeholder = "Email"
        if #available(iOS 12.0, *) {
            self.tfEmail.textContentType = .oneTimeCode
        }
        self.tfEmail.keyboardType = .emailAddress
        
        self.tfPassword.placeholder = "Contraseña"
        if #available(iOS 12.0, *) {
            self.tfPassword.textContentType = .oneTimeCode
        }
        self.tfPassword.keyboardType = .default
        self.tfPassword.autocorrectionType = .no
        self.tfPassword.isSecureTextEntry = true
        
        self.tfRepeatPassword.placeholder = "Repetir contraseña"
        if #available(iOS 12.0, *) {
            self.tfRepeatPassword.textContentType = .oneTimeCode
        }
        self.tfRepeatPassword.autocorrectionType = .no
        self.tfRepeatPassword.keyboardType = .default
        self.tfRepeatPassword.isSecureTextEntry = true
        
        self.title = "Registrarse"
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @IBAction func actionRegister(_ sender: Any) {
        if let email = tfEmail.text, let password = tfPassword.text, let repeatPassword = tfRepeatPassword.text {
            if !email.isValidEmail() {
                let alert = UIAlertController(title: "Error", message: "Introduce un email válido", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            } else if password == repeatPassword {
                self.tfPassword.becomeFirstResponder()
                self.tfRepeatPassword.becomeFirstResponder()
                self.webService.createUser(email: email, password: password)
            } else {
                let alert = UIAlertController(title: "Error", message: "Las contraseñas no coinciden", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        } else {
            let alert = UIAlertController(title: "Error", message: "No puede haber campos en blanco", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}

extension RegisterViewController: CreateUser {
    func userCreated(result: AuthDataResult) {
        let vc = PersonalDataSetViewController(nibName: "PersonalDataSetViewController", bundle: nil)
        vc.email = result.user.email!
        if let navigation = navigationController {
            navigation.pushViewController(vc, animated: true)
        }
    }
    
    func error(error: Error) {
        let alert = UIAlertController(title: "Error", message: "Se ha producido un error registrando el usuario", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}



