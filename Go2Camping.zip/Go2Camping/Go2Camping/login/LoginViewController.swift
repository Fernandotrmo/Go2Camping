//
//  LoginViewController.swift
//  Go2Camping
//
//  Created by Fernando Valentín Troncoso Moreno on 3/6/21.
//

import UIKit
import FirebaseAuth
import GoogleSignIn

class LoginViewController: UIViewController {
    
    @IBOutlet weak var stackView: UIStackView!
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnRegister: UIButton!
    @IBOutlet weak var btnGoogle: UIButton!
    @IBOutlet weak var btnForgotPassword: UIButton!
    
    var webService: WebService!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.loadStyles()
        webService = WebService(delegateCreateUser: self)
        GIDSignIn.sharedInstance()?.presentingViewController = self
        GIDSignIn.sharedInstance()?.delegate = self
        printFonts()
    }
    func printFonts() {
        for familyName in UIFont.familyNames {
            print("\n-- \(familyName) \n")
            for fontName in UIFont.fontNames(forFamilyName: familyName) {
                print(fontName)
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    private func loadStyles() {
        //Status bar
        let statusBarView = UIView()
        view.addSubview(statusBarView)
        statusBarView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            statusBarView.topAnchor.constraint(equalTo: view.topAnchor),
            statusBarView.leftAnchor.constraint(equalTo: view.leftAnchor),
            statusBarView.rightAnchor.constraint(equalTo: view.rightAnchor),
            statusBarView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor)
        ])
        statusBarView.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        navigationController?.navigationBar.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)

        self.view.backgroundColor = UIColor(red: 214/255, green: 234/255, blue: 248/255, alpha: 1)
        
        self.btnLogin.setTitle("Acceder", for: .normal)
        self.btnLogin.backgroundColor = UIColor(red: 88/255, green: 214/255, blue: 141/255, alpha: 1)
        self.btnLogin.setTitleColor(.white, for: .normal)
        self.btnLogin.titleLabel?.styleNameCommentCamping()
        
        self.btnRegister.setTitle("Registrar", for: .normal)
        self.btnRegister.backgroundColor = UIColor(red: 86/255, green: 101/255, blue: 115/255, alpha: 1)
        self.btnRegister.setTitleColor(.white, for: .normal)
        self.btnRegister.titleLabel?.styleNameCommentCamping()
        
        self.btnForgotPassword.setTitle("¿Has olvidado tu contraseña?", for: .normal)
        self.btnForgotPassword.backgroundColor = UIColor(red: 178/255, green: 186/255, blue: 187/255, alpha: 1)
        self.btnForgotPassword.setTitleColor(.white, for: .normal)
        self.btnForgotPassword.titleLabel?.styleNameCommentCamping()
        
        //add image
        let image = UIImage(named:"google")
        btnGoogle.setImage(image, for: .normal)
        btnGoogle.imageView?.contentMode = .scaleAspectFit
        btnGoogle.imageEdgeInsets = UIEdgeInsets(top:5, left: -60, bottom:5, right:0) //adjust these to have fit right
        
        //add title
        btnGoogle.setTitle("Entrar con Google", for: .normal)
        self.btnGoogle.titleLabel?.styleNameCommentCamping()
        self.btnGoogle.setTitleColor(.gray, for: .normal)
        self.btnGoogle.backgroundColor = .white
        btnGoogle.titleEdgeInsets = UIEdgeInsets(top:0, left:-200, bottom:0, right:0) //adjust insets to have fit how you want
        
        
        self.tfEmail.placeholder = "Email"
        self.tfEmail.keyboardType = .emailAddress
        
        self.tfPassword.placeholder = "Contraseña"
        self.tfPassword.isSecureTextEntry = true
        
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
        self.title = "Autenticación"
    }
    
    @IBAction func actionLogin(_ sender: Any) {
        if let email = tfEmail.text, let password = tfPassword.text {
            self.webService.login(email: email, password: password)
        }
    }
    
    @IBAction func actionLoginGoogle(_ sender: Any) {
        GIDSignIn.sharedInstance().signOut()
        GIDSignIn.sharedInstance().signIn()
    }
    
    @IBAction func actionForgotPassword(_ sender: Any) {
        let forgotPasswordAlert = UIAlertController(title: "¿Has olvidado tu contraseña?", message: "Introduce tu email para restablecerla", preferredStyle: .alert)
            forgotPasswordAlert.addTextField { (textField) in
                textField.placeholder = "Email"
            }
            forgotPasswordAlert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
            forgotPasswordAlert.addAction(UIAlertAction(title: "Restablecer contraseña", style: .default, handler: { (action) in
                let resetEmail = forgotPasswordAlert.textFields?.first?.text
                Auth.auth().sendPasswordReset(withEmail: resetEmail!, completion: { (error) in
                    if error != nil{
                        let resetFailedAlert = UIAlertController(title: "Error", message: "El usuario no está registrado en la base de datos, por favor, creese una cuenta.", preferredStyle: .alert)
                        resetFailedAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(resetFailedAlert, animated: true, completion: nil)
                    }else {
                        let resetEmailSentAlert = UIAlertController(title: "¡Éxito!", message: "Revisa tu email para restablecer la contraseña", preferredStyle: .alert)
                        resetEmailSentAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                        self.present(resetEmailSentAlert, animated: true, completion: nil)
                    }
                })
            }))
            //PRESENT ALERT
            self.present(forgotPasswordAlert, animated: true, completion: nil)
    }
    
    @IBAction func actionRegister(_ sender: Any) {
        let vc = RegisterViewController(nibName: "RegisterViewController", bundle: nil)
        if let navigation = navigationController {
            navigation.pushViewController(vc, animated: true)
        }
    }
    
    @objc func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
}

extension LoginViewController: CreateUser {
    func userCreated(result: AuthDataResult) {
        let vc = CampingListViewController(nibName: "CampingListViewController", bundle: nil)
        vc.email = result.user.email!
        vc.provider = .basic
        if let navigation = navigationController {
            navigation.pushViewController(vc, animated: true)
        }
    }
    
    func error(error: Error) {
        let alert = UIAlertController(title: "Error", message: "Se ha producido un error registrando el usuario", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
}

extension LoginViewController: GIDSignInDelegate {
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if error == nil && user != nil {
            let credential = GoogleAuthProvider.credential(withIDToken: user.authentication.idToken, accessToken: user.authentication.accessToken)
            
            Auth.auth().signIn(with: credential) { [weak self] result, error in
                guard let self = self else { return }
                if let result = result {
                    let vc = CampingListViewController(nibName: "CampingListViewController", bundle: nil)
                    vc.email = result.user.email!
                    vc.provider = .google
                    if let navigation = self.navigationController {
                        navigation.pushViewController(vc, animated: true)
                    }
                }
            }
        } else {
            if let error = error {
                let alert = UIAlertController(title: "Error", message: "Se ha producido un error registrando el usuario", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Aceptar", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    
}
